package com.ecommerce.ecommerce.service;

import com.ecommerce.ecommerce.dto.UserDTO;
import com.ecommerce.ecommerce.exception.Exceptions;
import com.ecommerce.ecommerce.model.User;
import com.ecommerce.ecommerce.repository.UserRepository;
import com.ecommerce.ecommerce.utility.mapper.Mappers;
import com.ecommerce.ecommerce.utility.security.AuthUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
@RequiredArgsConstructor
public class UserService {

    @Autowired
    private UserRepository repository;
    @Autowired
    private Mappers mappers;
    @Autowired
    private AuthUtil authUtil;

    public UserDTO.UserResponse getUser () {

        User authUser = authUtil.getCurrentUser();

        if (authUser == null) {
            throw new Exceptions.NotFoundException("User not found");
        }

        String email = authUser.getEmail();

        User user = repository.findByEmail(email)
                .orElseThrow(() -> new Exceptions.NotFoundException("User not found"));

        return mappers.mapUser(user);
    }

    public UserDTO.UserResponse updateUser(UserDTO.UpdateUserRequest request) {

        User user = authUtil.getCurrentUser();

        if (request == null) {
            throw new Exceptions.BadRequestException("Request body is empty");
        }

        // Update name
        if (request.name != null && !request.name.isBlank()) {
            user.setName(request.name);
        }

        // Update email (optional, but risky)
        if (request.email != null && !request.email.isBlank()) {
            // check if email already exists
            if (repository.findByEmail(request.email).isPresent()) {
                throw new Exceptions.BadRequestException("Email already in use");
            }
            user.setEmail(request.email);
        }

        User updated = repository.save(user);

        return mappers.mapUser(updated);
    }

    public void deleteUser () {
        User user = authUtil.getCurrentUser();

        if (repository.findByEmail(user.getEmail()).isEmpty()) {
            throw new Exceptions.NotFoundException("User Not Found");
        }

        repository.deleteById(user.getId());
    }
}
