package com.ecommerce.ecommerce.service;

import com.ecommerce.ecommerce.config.Enums;
import com.ecommerce.ecommerce.dto.OrderDTO;
import com.ecommerce.ecommerce.exception.Exceptions;
import com.ecommerce.ecommerce.model.*;
import com.ecommerce.ecommerce.repository.*;
import com.ecommerce.ecommerce.utility.mapper.Mappers;
import com.ecommerce.ecommerce.utility.security.AuthUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final Mappers mappers;
    private final AuthUtil authUtil;
    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final OrderRepository orderRepository;
    private final ProductRepository productRepository; // ✅ ADDED

    // ✅ CREATE ORDER
    @Transactional
    public OrderDTO.OrderResponse createOrder() {

        User user = authUtil.getCurrentUser();

        Cart cart = cartRepository.findByUser(user)
                .orElseThrow(() -> new Exceptions.NotFoundException("Cart not found"));

        if (cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new Exceptions.BadRequestException("Cart is empty");
        }

        Order order = new Order();
        order.setUser(user);

        List<OrderItem> orderItems = new ArrayList<>();
        double total = 0;

        for (CartItem cartItem : cart.getItems()) {

            Product product = cartItem.getProduct();

            // ✅ STOCK CHECK
            if (cartItem.getQuantity() > product.getStock()) {
                throw new Exceptions.BadRequestException(
                        "Insufficient stock for " + product.getName()
                );
            }

            // ✅ REDUCE STOCK + SAVE
            product.setStock(product.getStock() - cartItem.getQuantity());
            productRepository.save(product);

            // ✅ CREATE ORDER ITEM
            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setProduct(product);
            item.setQuantity(cartItem.getQuantity());
            item.setPrice(product.getPrice());

            total += product.getPrice() * cartItem.getQuantity();

            orderItems.add(item);
        }

        order.setItems(orderItems);
        order.setTotalAmount(total);

        Order savedOrder = orderRepository.save(order);

        // ✅ CLEAR CART
        cartItemRepository.deleteAll(cart.getItems());
        cart.getItems().clear();
        cartRepository.save(cart);

        return mappers.mapOrder(savedOrder);
    }

    // ✅ GET USER ORDERS
    public List<OrderDTO.OrderResponse> getMyOrders() {

        User user = authUtil.getCurrentUser();

        return orderRepository.findByUser(user)
                .stream()
                .map(mappers::mapOrder)
                .toList();
    }

    // ✅ UPDATE ORDER STATUS (ADMIN ONLY)
    public OrderDTO.OrderResponse updateOrderStatus(OrderDTO.UpdateOrderStatusRequest request) {

        User user = authUtil.getCurrentUser();

        // ✅ ADMIN CHECK
        if (user.getRole() != Enums.USER_ROLE.ADMIN) {
            throw new Exceptions.UnauthorizedException("Only admin can update order status");
        }

        Order order = orderRepository.findById(request.orderId)
                .orElseThrow(() ->
                        new Exceptions.NotFoundException("Order not found"));

        Enums.OrderStatus newStatus;

        try {
            newStatus = Enums.OrderStatus.valueOf(String.valueOf(request.status));
        } catch (Exception e) {
            throw new Exceptions.BadRequestException("Invalid order status");
        }

        // ✅ VALIDATION RULES
        if (order.getStatus() == Enums.OrderStatus.PLACED &&
                newStatus == Enums.OrderStatus.DELIVERED) {
            throw new Exceptions.BadRequestException("Invalid status transition");
        }

        if (order.getStatus() == Enums.OrderStatus.DELIVERED) {
            throw new Exceptions.BadRequestException("Order already delivered");
        }

        order.setStatus(newStatus);

        Order updated = orderRepository.save(order);

        return mappers.mapOrder(updated);
    }
}