package com.ecommerce.ecommerce.service;

import com.ecommerce.ecommerce.dto.CartDTO;
import com.ecommerce.ecommerce.exception.Exceptions;
import com.ecommerce.ecommerce.model.Cart;
import com.ecommerce.ecommerce.model.CartItem;
import com.ecommerce.ecommerce.model.Product;
import com.ecommerce.ecommerce.model.User;
import com.ecommerce.ecommerce.repository.CartItemRepository;
import com.ecommerce.ecommerce.repository.CartRepository;
import com.ecommerce.ecommerce.repository.ProductRepository;
import com.ecommerce.ecommerce.utility.mapper.Mappers;
import com.ecommerce.ecommerce.utility.security.AuthUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CartService {

    @Autowired
    private CartRepository cartRepository;
    @Autowired
    private AuthUtil authUtil;
    @Autowired
    private CartItemRepository cartItemRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private Mappers mappers;

    public CartDTO.CartResponse addToCart(CartDTO.AddToCartRequest request) {

        if (request == null || request.productId == null || request.quantity == null) {
            throw new Exceptions.BadRequestException("Invalid request");
        }

        if (request.quantity <= 0) {
            throw new Exceptions.BadRequestException("Quantity must be greater than 0");
        }

        User user = authUtil.getCurrentUser();

        // 1. Get or create cart
        Cart cart = cartRepository.findByUser(user)
                .orElseGet(() -> {
                    Cart newCart = new Cart();
                    newCart.setUser(user);
                    return cartRepository.save(newCart);
                });

        // 2. Get product
        Product product = productRepository.findById(request.productId)
                .orElseThrow(() ->
                        new Exceptions.NotFoundException("Product not found"));

        // 3. Check if item already exists
        CartItem existingItem = cartItemRepository
                .findByCartAndProduct(cart, product)
                .orElse(null);

        if (existingItem != null) {

            int newQuantity = existingItem.getQuantity() + request.quantity;

            // stock check
            if (newQuantity > product.getStock()) {
                throw new Exceptions.BadRequestException("Not enough stock available");
            }

            existingItem.setQuantity(newQuantity);
            cartItemRepository.save(existingItem);

        } else {

            if (request.quantity > product.getStock()) {
                throw new Exceptions.BadRequestException("Not enough stock available");
            }

            CartItem item = new CartItem();
            item.setCart(cart);
            item.setProduct(product);
            item.setQuantity(request.quantity);

            cartItemRepository.save(item);
        }

        return mappers.mapCart(cart);
    }

    public CartDTO.CartResponse getCart() {

        User user = authUtil.getCurrentUser();

        Cart cart = cartRepository.findByUser(user)
                .orElse(null);

        // If no cart yet, return empty response
        if (cart == null || cart.getItems() == null) {
            CartDTO.CartResponse empty = new CartDTO.CartResponse();
            empty.cartId = null;
            empty.items = List.of();
            empty.totalPrice = 0.0;
            return empty;
        }

        return mappers.mapCart(cart);
    }

    public CartDTO.CartResponse removeItem(Long productId) {

        User user = authUtil.getCurrentUser();

        Cart cart = cartRepository.findByUser(user)
                .orElseThrow(() -> new Exceptions.NotFoundException("Cart not found"));

        CartItem item = cartItemRepository.findByCartAndProductId(cart, productId)
                .orElseThrow(() -> new Exceptions.NotFoundException("Item not found in cart"));

        cartItemRepository.delete(item);

        return mappers.mapCart(cart);
    }

    public CartDTO.CartResponse updateQuantity(Long productId, Integer quantity) {

        if (quantity == null || quantity < 0) {
            throw new Exceptions.BadRequestException("Invalid quantity");
        }

        User user = authUtil.getCurrentUser();

        Cart cart = cartRepository.findByUser(user)
                .orElseThrow(() -> new Exceptions.NotFoundException("Cart not found"));

        CartItem item = cartItemRepository.findByCartAndProductId(cart, productId)
                .orElseThrow(() -> new Exceptions.NotFoundException("Item not found"));

        Product product = item.getProduct();

        if (quantity == 0) {
            cartItemRepository.delete(item);
        } else {

            if (quantity > product.getStock()) {
                throw new Exceptions.BadRequestException("Not enough stock");
            }

            item.setQuantity(quantity);
            cartItemRepository.save(item);
        }

        return mappers.mapCart(cart);
    }

    public CartDTO.CartResponse clearCart() {

        User user = authUtil.getCurrentUser();

        Cart cart = cartRepository.findByUser(user)
                .orElseThrow(() -> new Exceptions.NotFoundException("Cart not found"));

        cartItemRepository.deleteAll(cart.getItems());

        cart.getItems().clear();

        return mappers.mapCart(cart);
    }

}
