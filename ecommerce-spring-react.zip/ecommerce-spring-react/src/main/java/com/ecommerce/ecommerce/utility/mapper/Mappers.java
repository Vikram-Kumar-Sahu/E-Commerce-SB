package com.ecommerce.ecommerce.utility.mapper;

import com.ecommerce.ecommerce.dto.*;
import com.ecommerce.ecommerce.model.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Mappers {

    public UserDTO.UserResponse mapUser (User user) {
        UserDTO.UserResponse dto = new UserDTO.UserResponse();

        dto.id = user.getId();
        dto.name = user.getName();
        dto.email = user.getEmail();

        return dto;
    }

    public AuthDTO.AuthResponse mapAuthUser (User user, String token) {
        AuthDTO.AuthResponse response = new AuthDTO.AuthResponse();

        response.id = user.getId();
        response.name = user.getName();
        response.email = user.getEmail();
        response.token = token;

        return response;
    }

    public ProductDTO.ProductResponse mapProduct (Product product) {
        ProductDTO.ProductResponse response = new ProductDTO.ProductResponse();

        response.id = product.getId();
        response.name = product.getName();
        response.description = product.getDescription();
        response.price = product.getPrice();
        response.stock = product.getStock();

        // 🔥 ADD THIS LINE (THIS IS THE FIX)
        response.imageUrl = product.getImageUrl();

        response.createdBy = product.getCreatedBy().getEmail();

        return response;
    }

    public CartDTO.CartItemResponse mapCartItem(CartItem item) {

        CartDTO.CartItemResponse res = new CartDTO.CartItemResponse();

        Product product = item.getProduct();

        res.productId = product.getId();
        res.name = product.getName();
        res.imageUrl = product.getImageUrl();
        res.price = product.getPrice();
        res.quantity = item.getQuantity();

        res.totalPrice = product.getPrice() * item.getQuantity();

        return res;
    }

    public CartDTO.CartResponse mapCart(Cart cart) {

        CartDTO.CartResponse response = new CartDTO.CartResponse();

        response.cartId = cart.getId();

        List<CartDTO.CartItemResponse> items = cart.getItems()
                .stream()
                .map(this::mapCartItem)
                .toList();

        response.items = items;

        response.totalPrice = items.stream()
                .mapToDouble(item -> item.totalPrice)
                .sum();

        return response;
    }

    public OrderDTO.OrderItemResponse mapOrderItem(OrderItem item) {

        OrderDTO.OrderItemResponse res = new OrderDTO.OrderItemResponse();

        Product product = item.getProduct();

        res.productId = product.getId();
        res.productName = product.getName();
        res.imageUrl = product.getImageUrl();

        res.quantity = item.getQuantity();
        res.price = item.getPrice();

        res.totalPrice = item.getPrice() * item.getQuantity();

        return res;
    }

    public OrderDTO.OrderResponse mapOrder(Order order) {

        OrderDTO.OrderResponse res = new OrderDTO.OrderResponse();

        res.orderId = order.getId();
        res.totalAmount = order.getTotalAmount();
        res.status = order.getStatus().name();
        res.createdAt = order.getCreatedAt().toString();

        List<OrderDTO.OrderItemResponse> items = order.getItems()
                .stream()
                .map(this::mapOrderItem)
                .toList();

        res.items = items;

        return res;
    }
}
