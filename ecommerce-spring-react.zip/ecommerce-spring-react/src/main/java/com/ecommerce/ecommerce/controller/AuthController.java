package com.ecommerce.ecommerce.controller;

import com.ecommerce.ecommerce.dto.AuthDTO;
import com.ecommerce.ecommerce.exception.Exceptions;
import com.ecommerce.ecommerce.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    @Autowired
    private AuthService service;

    @PostMapping("/register")
    public ResponseEntity<AuthDTO.AuthResponse> RegisterUser (@RequestBody AuthDTO.RegisterRequest request) {
        if (request == null) {
            throw new Exceptions.BadRequestException("Request body is empty");
        }
        AuthDTO.AuthResponse response = service.register(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthDTO.AuthResponse> LoginUser (@RequestBody AuthDTO.LoginRequest request) {
        if (request == null) {
            throw new Exceptions.BadRequestException("Request body is empty");
        }
        AuthDTO.AuthResponse response = service.login(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
