package com.ecommerce.ecommerce.dto;

public class UserDTO {

    public static class UpdateUserRequest {
        public String name;
        public String email;
    }

    public static class UserResponse {
        public Long id;
        public String name;
        public String email;
    }
}
