package com.ecommerce.ecommerce.dto;

import java.util.List;

public class CartDTO {

    public static class AddToCartRequest {
        public Long productId;
        public Integer quantity;
    }

    public static class CartItemResponse {
        public Long productId;
        public String name;
        public String imageUrl;
        public Double price;
        public Integer quantity;
        public Double totalPrice;
    }

    public static class CartResponse {
        public Long cartId;
        public List<CartItemResponse> items;
        public Double totalPrice;
    }

}
