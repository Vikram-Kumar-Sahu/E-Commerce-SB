package com.ecommerce.ecommerce.service;

import com.ecommerce.ecommerce.config.Enums;
import com.ecommerce.ecommerce.dto.AuthDTO;
import com.ecommerce.ecommerce.exception.Exceptions;
import com.ecommerce.ecommerce.model.User;
import com.ecommerce.ecommerce.repository.UserRepository;
import com.ecommerce.ecommerce.utility.mapper.Mappers;
import com.ecommerce.ecommerce.utility.security.Jwt;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    @Autowired
    private UserRepository repository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private Mappers mappers;
    private final Jwt jwtUtil;

    public AuthDTO.AuthResponse register (AuthDTO.RegisterRequest request) {

        if (request.email.isBlank() || request.name.isBlank() || request.password.isBlank()) {
            throw new Exceptions.BadRequestException("All fields are required");
        }

        if (repository.findByEmail(request.email).isPresent()) {
            throw new Exceptions.BadRequestException("User already exists");
        }

        User user = new User();
        user.setEmail(request.email);
        user.setPassword(passwordEncoder.encode(request.password));
        user.setRole(Enums.USER_ROLE.USER);

        User savedUser = repository.save(user);

        String token = jwtUtil.generateToken(user.getEmail());

        return mappers.mapAuthUser(user, token);
    }

    public AuthDTO.AuthResponse login (AuthDTO.LoginRequest request) {

        if (request.email.isBlank() || request.password.isBlank()) {
            throw new Exceptions.BadRequestException("All fields are required");
        }

        User user = repository.findByEmail(request.email)
                .orElseThrow(() -> new Exceptions.NotFoundException("User not found"));

        if (!passwordEncoder.matches(request.password, user.getPassword())) {
            throw new Exceptions.BadRequestException("Invalid password");
        }

        String token = jwtUtil.generateToken(user.getEmail());

        return mappers.mapAuthUser(user, token);
    }
}
