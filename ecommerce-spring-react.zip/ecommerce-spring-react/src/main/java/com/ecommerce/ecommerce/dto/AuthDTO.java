package com.ecommerce.ecommerce.dto;

public class AuthDTO {

    public static class RegisterRequest {
        public String name;
        public String email;
        public String password;
    }

    public static class LoginRequest {
        public String email;
        public String password;
    }

    public static  class AuthResponse {
        public Long id;
        public String name;
        public String email;
        public String token;
    }

}
