package com.ecommerce.ecommerce.service;

import com.ecommerce.ecommerce.dto.ProductDTO;
import com.ecommerce.ecommerce.exception.Exceptions;
import com.ecommerce.ecommerce.model.Product;
import com.ecommerce.ecommerce.model.User;
import com.ecommerce.ecommerce.repository.ProductRepository;
import com.ecommerce.ecommerce.utility.mapper.Mappers;
import com.ecommerce.ecommerce.utility.security.AuthUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductService {

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private Mappers mappers;
    @Autowired
    private AuthUtil authUtil;

    public List<ProductDTO.ProductResponse> findAll () {

        List<Product> products = productRepository.findAll();
        return products.stream()
                .map(mappers::mapProduct)
                .toList();
    }

    public ProductDTO.ProductResponse findById(Long id) {

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new Exceptions.NotFoundException("Product not found"));

        return mappers.mapProduct(product);
    }

    public ProductDTO.ProductResponse create (ProductDTO.CreateProductRequest request) {

        if (request.name.isBlank() || request.description.isBlank()) {
            throw new Exceptions.BadRequestException("Name and description are required");
        }

        if (request.price <= 0) {
            throw new Exceptions.BadRequestException("Price cannot be 0");
        }

        User user = authUtil.getCurrentUser();
        Product product = new Product();

        product.setName(request.name.trim());
        product.setDescription(request.description.trim());
        product.setPrice(request.price);
        product.setStock(1);
        if (request.imageUrl != null && !request.imageUrl.isBlank()) {
            product.setImageUrl(request.imageUrl);
        }
        product.setCreatedBy(user);

        Product savedProduct = productRepository.save(product);

        return mappers.mapProduct(savedProduct);
    }

    public void deleteProduct (Long id) {
        User user = authUtil.getCurrentUser();

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new Exceptions.NotFoundException("Product not found"));

        if (!product.getCreatedBy().getId().equals(user.getId())) {
            throw new Exceptions.UnauthorizedException("You cannot delete this product");
        }

        productRepository.deleteById(id);
    }

    public ProductDTO.ProductResponse update(
            Long id,
            ProductDTO.CreateProductRequest request
    ) {
        if (request == null) {
            throw new Exceptions.BadRequestException("Request body is empty");
        }

        Product product = productRepository.findById(id)
                .orElseThrow(() ->
                        new Exceptions.NotFoundException("Product not found"));

        User currentUser = authUtil.getCurrentUser();

        // Ownership check (important)
        if (!product.getCreatedBy().getId().equals(currentUser.getId())) {
            throw new Exceptions.UnauthorizedException("You are not allowed to update this product");
        }

        // Update name
        if (request.name != null && !request.name.isBlank()) {
            product.setName(request.name.trim());
        }

        // Update description
        if (request.description != null && !request.description.isBlank()) {
            product.setDescription(request.description.trim());
        }

        // Update price
        if (request.price != null) {
            if (request.price <= 0) {
                throw new Exceptions.BadRequestException("Price must be greater than 0");
            }
            product.setPrice(request.price);
        }

        // Update stock
        if (request.stock != null) {
            if (request.stock < 0) {
                throw new Exceptions.BadRequestException("Stock cannot be negative");
            }
            product.setStock(request.stock);
        }

        // Update image
        if (request.imageUrl != null && !request.imageUrl.isBlank()) {
            product.setImageUrl(request.imageUrl);
        }

        Product updated = productRepository.save(product);

        return mappers.mapProduct(updated);
    }

}
