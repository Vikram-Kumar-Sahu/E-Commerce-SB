package com.ecommerce.ecommerce.config;

public class Enums {

    public enum USER_ROLE {
        USER,
        ADMIN
    }

    public enum OrderStatus {
        PLACED,
        CONFIRMED,
        SHIPPED,
        DELIVERED,
        CANCELLED
    }
}
