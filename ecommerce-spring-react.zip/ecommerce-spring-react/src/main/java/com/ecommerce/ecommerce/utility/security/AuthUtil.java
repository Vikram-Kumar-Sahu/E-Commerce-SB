package com.ecommerce.ecommerce.utility.security;

import com.ecommerce.ecommerce.exception.Exceptions;
import com.ecommerce.ecommerce.model.User;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class AuthUtil {

    public User getCurrentUser() {
        Object principal = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();

        if (principal instanceof User user) {
            return user;
        }

        throw new Exceptions.UnauthorizedException("User not authenticated");
    }

    public String getCurrentUserEmail() {
        Object principal = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();

        if (principal instanceof User user) {
            return user.getEmail();
        }

        return SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();
    }
}
