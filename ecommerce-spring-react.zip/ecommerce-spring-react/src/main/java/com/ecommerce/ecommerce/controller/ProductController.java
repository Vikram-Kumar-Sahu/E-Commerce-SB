package com.ecommerce.ecommerce.controller;
import com.ecommerce.ecommerce.dto.ProductDTO;
import com.ecommerce.ecommerce.model.Product;
import com.ecommerce.ecommerce.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService service;

    @GetMapping
    public ResponseEntity<List<ProductDTO.ProductResponse>> getAll() {
        List<ProductDTO.ProductResponse> products = service.findAll();
        return ResponseEntity.status(HttpStatus.OK).body(products);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductDTO.ProductResponse> getById(@PathVariable String id) {
        ProductDTO.ProductResponse product = service.findById(Long.parseLong(id));
        return ResponseEntity.status(HttpStatus.OK).body(product);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable String id) {
        service.deleteProduct(Long.parseLong(id));
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductDTO.ProductResponse> updateProduct(@PathVariable String id, @RequestBody ProductDTO.CreateProductRequest request) {
        ProductDTO.ProductResponse product = service.update(Long.parseLong(id), request);
        return ResponseEntity.status(HttpStatus.OK).body(product);
    }

    @PostMapping
    public ResponseEntity<ProductDTO.ProductResponse> create(@RequestBody ProductDTO.CreateProductRequest request) {
        ProductDTO.ProductResponse product = service.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(product);
    }
}