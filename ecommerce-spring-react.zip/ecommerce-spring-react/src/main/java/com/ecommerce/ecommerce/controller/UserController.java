package com.ecommerce.ecommerce.controller;

import com.ecommerce.ecommerce.dto.UserDTO;
import com.ecommerce.ecommerce.model.User;
import com.ecommerce.ecommerce.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {

    @Autowired
    private UserService service;

    @GetMapping("/profile")
    public ResponseEntity<UserDTO.UserResponse> findByEmail() {
        UserDTO.UserResponse user = service.getUser();
        return ResponseEntity.status(HttpStatus.OK).body(user);
    }

    @PutMapping("/profile")
    public ResponseEntity<UserDTO.UserResponse> updateUser(
            @RequestBody UserDTO.UpdateUserRequest request
    ) {
        UserDTO.UserResponse user = service.updateUser(request);
        return ResponseEntity.status(HttpStatus.OK).body(user);
    }

    @DeleteMapping("/profile")
    public ResponseEntity<Void> deleteUser() {
        service.deleteUser();
        return ResponseEntity.noContent().build();
    }
}
