package com.ecommerce.ecommerce.dto;

public class ProductDTO {

    public static class CreateProductRequest {
        public String imageUrl;
        public String name;
        public String description;
        public Double price;
        public Integer stock;
    }

    public static class ProductResponse {
        public Long id;
        public String imageUrl;
        public String name;
        public String description;
        public Double price;
        public Integer stock;

        public String createdBy;
    }
}
