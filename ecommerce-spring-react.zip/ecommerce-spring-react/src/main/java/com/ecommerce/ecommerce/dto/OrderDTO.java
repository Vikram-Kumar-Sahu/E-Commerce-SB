package com.ecommerce.ecommerce.dto;

import com.ecommerce.ecommerce.config.Enums;

import java.util.List;

public class OrderDTO {

    public static class OrderItemResponse {

        public Long productId;
        public String productName;
        public String imageUrl;

        public Integer quantity;
        public Double price;
        public Double totalPrice;
    }

    public static class OrderResponse {

        public Long orderId;
        public Double totalAmount;
        public String status;
        public String createdAt;

        public List<OrderItemResponse> items;
    }

    public static class UpdateOrderStatusRequest {
        public Long orderId;
        public Enums.OrderStatus status;
    }
}
