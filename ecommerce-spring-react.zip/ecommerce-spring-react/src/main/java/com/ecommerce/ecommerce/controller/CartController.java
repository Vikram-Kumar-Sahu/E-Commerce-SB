package com.ecommerce.ecommerce.controller;

import com.ecommerce.ecommerce.dto.CartDTO;
import com.ecommerce.ecommerce.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService service;

    @PostMapping
    public ResponseEntity<CartDTO.CartResponse> addToCart(@RequestBody CartDTO.AddToCartRequest request) {
        return ResponseEntity.ok(service.addToCart(request));
    }

    @GetMapping
    public ResponseEntity<CartDTO.CartResponse> getCart() {
        return ResponseEntity.ok(service.getCart());
    }

    @DeleteMapping("/item/{productId}")
    public ResponseEntity<CartDTO.CartResponse> removeItem(@PathVariable String productId) {
        return ResponseEntity.ok(service.removeItem(Long.parseLong(productId)));
    }

    @PutMapping("/item/{productId}")
    public ResponseEntity<CartDTO.CartResponse> updateQuantity(
            @PathVariable String productId,
            @RequestParam Integer quantity
    ) {
        return ResponseEntity.ok(service.updateQuantity(Long.parseLong(productId), quantity));
    }

    @DeleteMapping("/clear")
    public ResponseEntity<CartDTO.CartResponse> clearCart() {
        return ResponseEntity.ok(service.clearCart());
    }

}
