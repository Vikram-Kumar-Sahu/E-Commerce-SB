package com.ecommerce.ecommerce.controller;

import com.ecommerce.ecommerce.dto.OrderDTO;
import com.ecommerce.ecommerce.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/order")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService service;

    @PostMapping
    public ResponseEntity<OrderDTO.OrderResponse> createOrder() {
        return ResponseEntity.ok(service.createOrder());
    }

    @GetMapping
    public ResponseEntity<List<OrderDTO.OrderResponse>> getMyOrders() {
        return ResponseEntity.ok(service.getMyOrders());
    }

    @PutMapping("/status")
    public ResponseEntity<OrderDTO.OrderResponse> updateStatus(
            @RequestBody OrderDTO.UpdateOrderStatusRequest request
    ) {
        return ResponseEntity.ok(service.updateOrderStatus(request));
    }
}
